-----------------------------

Difficulty Scaler
by Thrakal

-----------------------------

- Find more information about this mod at https://www.cozyheim.dk

-----------------------------

All of my mods are developed in my spare time and takes a lot of time to create and maintain.

I would therefore appreciate your support
making it possible for me to spend more time on creating mods for you to enjoy!

Cosider donating a horn of mead:
https://www.buymeacoffee.com/Thrakal